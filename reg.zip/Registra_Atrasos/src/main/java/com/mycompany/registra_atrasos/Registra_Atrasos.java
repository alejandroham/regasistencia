/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registra_atrasos;

/**
 *
 * @author estudiante 3 TP
 */
public class Registra_Atrasos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
